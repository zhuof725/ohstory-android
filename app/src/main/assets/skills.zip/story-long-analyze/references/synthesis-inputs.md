# Stage 3–5：取料与事实保真

Stage 3、4、5 各自的时刻都读本文件。

## 取料

用只读的 `digest` 按需提取跨章观察和逐章字段，避免重复读取缓存里的章节正文；输出为 Markdown：

```text
"{PYTHON}" "{story-long-analyze skill 根}/scripts/manage_analysis_run.py" digest --root "{拆文目录}" --part observations [--chapters 1-60]
"{PYTHON}" "{story-long-analyze skill 根}/scripts/manage_analysis_run.py" digest --root "{拆文目录}" --part chapters --chapters 1-60 --fields 三维节奏,涉及,状态变化 --points brief
```

- `observations`：按章序汇总已提交批次的跨章观察（剧情点、关键事件与披露候选、关系变化、三维峰谷、跨批状态），是 Stage 3–4 的主语料；
- `chapters`：从逐章摘要抽字段（概要、关键事件、因果、局面结果、涉及、信息变化、状态变化、三维节奏、章尾钩子、证据），`--points brief` 给每点「标题｜类型｜基调」，`full` 另带白描；
- 全书放不进一次上下文时按 `--chapters` 分窗口取、分组合并，窗口间只带剧情状态、关键候选与证据引用，不扩写内容；只有关键证据冲突才定点 Read 单章 `章节/第N章_摘要.md`，最多增加一次定点核验；
- 旧项目没有批次缓存时，直接复用现有剧情、节奏、情绪、关系和逐章资料，不要为了统一格式先把旧摘要重新压缩一遍；证据不足或冲突时标未知或待核；
- Stage 3–5 不回读原文，也不各自重读同一批原文；Stage 6 可以按索引定点读取 4–6 段文风锚点，但不得重新扫描整本原文。

## 证据等级

剧情单元、节奏、情绪模块、角色关系等底层文件里的推断按三级标注：

- `A 明确`：输入资料直接给出；
- `B 强推断`：多个明确细节共同支持；
- `C 暂定`：证据不足，只留作待核。

给作者看的报告不写字母，按 author-facing「证据强弱说人话」转述。

## 阶段标记

Stage 3–5 各运行一次，失败后按缺口重试。文件成功落盘后再标记：

```text
"{PYTHON}" "{story-long-analyze skill 根}/scripts/manage_analysis_run.py" mark-stage \
  --root "{拆文目录}" --stage stage3 --output "剧情/节奏.md"
```

`mark-stage` 只检查约定产物存在且非空：Stage 3 要情绪模块与节奏两份都在（用上面的 `--output`），Stage 4 要至少一份角色档案（`角色关系.md` 不算）和一份设定，Stage 5 要报告。语义质量仍按各阶段规则验收。Stage 1–2 的标记见 pipeline-ops.md，Stage 6 见 style-profile-generator.md。

## 合成阶段事实保真（阶段 3-5：剧情/设定/角色/报告）

阶段 3–5 复用已有事实，不凭常识或惯例补齐资料未给的信息，也不为聚合回读原文：

1. **硬事实可溯源**：力量等级、数值、距离、属性、势力数量、台词归属、角色出场章节须能回指批次证据（原句与 `source_locator`）或计划列出的旧成果；查不到就改写为「原文未明确 / 节选未涉及 / 旧资料未提供」或删除。
2. **跨指代不串**：相邻实体的属性、等级、台词、章节统计数字不互相挪用。

落盘后逐条抽查设定、角色和报告里的硬事实，确认均可回指本次允许使用的证据源。
